package model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.DiaDanh;
import model.bean.DiaPhuong;
import model.bean.HuongDanVien;
import model.bean.KhachHang;

/**				
 * DiaDanhDAO.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class DiaDanhDAO {
	
	String url = "jdbc:sqlserver://localhost:1433;databaseName=iTravel";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	Statement stmt;
	
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}
	
	public ArrayList<DiaDanh> getListDiaDanh() {
		connect();
		String sql=	"select * from DIADANH";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DiaDanh> list = new ArrayList<DiaDanh>();
		DiaDanh diaDanh;
		try {
			while(rs.next()){
				diaDanh = new DiaDanh();
				diaDanh.setMaDiaDanh(rs.getString("MaDiaDanh"));
				diaDanh.setTenDiaDanh(rs.getString("TenDiaDanh"));
				diaDanh.setDienTich(rs.getInt("DienTich"));
				diaDanh.setGioiThieu(rs.getString("GioiThieu"));
				diaDanh.setDanhGia(rs.getString("DanhGia"));
				diaDanh.setMaDiaPhuong(rs.getString("MaDiaPhuong"));
				diaDanh.setSoLuongNguoi(rs.getInt("SoLuongNguoi"));
				list.add(diaDanh);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<KhachHang> getListKH() {
		connect();
		String sql=	"SELECT MaKH, HoTen FROM KHACHHANG";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<KhachHang> list = new ArrayList<KhachHang>();
		KhachHang khachHang;
		try {
			while(rs.next()){
				khachHang = new KhachHang();
				khachHang.setMaKH(rs.getString("MaKH"));
				khachHang.setTenKH(rs.getString("HoTen"));
				list.add(khachHang);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<DiaPhuong> getListDiaPhuong() {
		connect();
		String sql=	"SELECT * FROM DIAPHUONG";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DiaPhuong> list = new ArrayList<DiaPhuong>();
		DiaPhuong diaPhuong;
		try {
			while(rs.next()){
				diaPhuong = new DiaPhuong();
				diaPhuong.setMaDiaPhuong(rs.getString("MaDiaPhuong"));
				diaPhuong.setTenDiaPhuong(rs.getString("TenDiaPhuong"));
				list.add(diaPhuong);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<HuongDanVien> getListHDV() {
		connect();
		String sql=	"SELECT MaHDV, HoTen FROM HUONGDANVIEN";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<HuongDanVien> list = new ArrayList<HuongDanVien>();
		HuongDanVien huongDanVien;
		try {
			while(rs.next()){
				huongDanVien = new HuongDanVien();
				huongDanVien.setMaHDV(rs.getString("MaHDV"));
				huongDanVien.setHoTen(rs.getString("HoTen"));
				list.add(huongDanVien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public void themChuyenDi(String maKH, String maDiaDanh, String maHDV, int soLuongNguoi, int mucPhi) {
		connect();
		String sql=	String.format("INSERT INTO CHUYENDI(MaKH,MaDiaDanh,MaHDV,SoLuongNguoi,MucPhi) "+
					" VALUES ( '%s',N'%s','%s','%s','%s' )", maKH, maDiaDanh, maHDV, soLuongNguoi,mucPhi);
		
		String sql1= String.format("Update DIADANH set SoLuongNguoi = SoLuongNguoi + '%s' where MaDiaDanh = '%s'", soLuongNguoi, maDiaDanh);
		String sql2= String.format("Update KHACHHANG set DiemThuong = DiemThuong + 200 where maKH = '%s'", maKH);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
			stmt.executeUpdate(sql1);
			stmt.executeUpdate(sql2);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public DiaDanh getThongTinDiaDanh(String maDiaDanh) {
		connect();
		String sql=	String.format("SELECT * FROM DIADANH WHERE MaDiaDanh = '%s'", maDiaDanh);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		DiaDanh diaDanh = new DiaDanh();
		try {
			while(rs.next()){
				diaDanh.setMaDiaDanh(maDiaDanh);
				diaDanh.setTenDiaDanh(rs.getString("TenDiaDanh"));
				diaDanh.setDienTich(rs.getInt("DienTich"));
				diaDanh.setGioiThieu(rs.getString("GioiThieu"));
				diaDanh.setDanhGia(rs.getString("DanhGia"));
				diaDanh.setMaDiaPhuong(rs.getString("MaDiaPhuong"));
				diaDanh.setSoLuongNguoi(rs.getInt("SoLuongNguoi"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return diaDanh;
	}
	
	public void suaDiaDanh(String maDiaDanh, String tenDiaDanh, int dienTich, String gioiThieu,String danhGia, String maDiaPhuong, int soLuongNguoi) {
		connect();
		String sql=	String.format("UPDATE DIADANH "+
					" SET TenDiaDanh = '%s', DienTich = '%s', "
				  + "GioiThieu = N'%s', DanhGia = N'%s', MaDiaPhuong = N'%s', "
				  + "SoLuongNguoi = N'%s' WHERE MaDiaDanh = '%s'", tenDiaDanh, dienTich, gioiThieu,danhGia, maDiaPhuong, soLuongNguoi, maDiaDanh);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	CallableStatement callstmt = null;
	
	public KhachHang getTienHoanTra(String maKH) {
	connect();
	String sql=	String.format("Select  SUM(MucPhi) as TongTien, DiemThuong "
			+ "from CHUYENDI inner join KHACHHANG on "
			+ "CHUYENDI.MaKH = KHACHHANG.MaKH where KHACHHANG.MaKH = '%s' "
			+ "group by DiemThuong", maKH);
	ResultSet rs = null;
	try {
		Statement stmt = connection.createStatement();
		rs = stmt.executeQuery(sql);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	KhachHang khachHang = new KhachHang();
	try {
		while(rs.next()){
			khachHang.setTongTien(rs.getInt("TongTien"));
			khachHang.setDiemThuong(rs.getInt("DiemThuong"));
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return khachHang;
}
	public static void main(String[] args) {
		DiaDanhDAO dao = new DiaDanhDAO();
		System.out.println(""+dao.getTienHoanTra("KH001").getDiemThuong());
	}

	public ArrayList<DiaDanh> getListDiaDanhTimKiem(String searchText) {
		connect();
		String sql=	"SELECT * FROM DIADANH "
				+" WHERE MaDiaDanh like N'%"+searchText+"%' or "
				+ "TenDiaDanh like N'%"+searchText+"%' or DienTich like N'%"+searchText+"%'"
				+ "or GioiThieu like N'%"+searchText+"%' or DanhGia like N'%"+searchText+"%'"
				+ "or MaDiaPhuong like N'%"+searchText+"%' or SoLuongNguoi like N'%"+searchText+"%'";
		ResultSet rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DiaDanh> list = new ArrayList<DiaDanh>();
		DiaDanh diaDanh;
		try {
			while(rs.next()){
				diaDanh = new DiaDanh();
				diaDanh.setMaDiaDanh(rs.getString("MaDiaDanh"));
				diaDanh.setTenDiaDanh(rs.getString("TenDiaDanh"));
				diaDanh.setDienTich(rs.getInt("DienTich"));
				diaDanh.setGioiThieu(rs.getString("GioiThieu"));
				diaDanh.setDanhGia(rs.getString("DanhGia"));
				diaDanh.setMaDiaPhuong(rs.getString("MaDiaPhuong"));
				diaDanh.setSoLuongNguoi(rs.getInt("SoLuongNguoi"));
				list.add(diaDanh);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public void xoaDiaDanh(String maDiaDanh) {
		connect();
		String sql=	String.format("DELETE FROM DIADANH WHERE MaDiaDanh = '%s'", maDiaDanh);
		System.out.println(sql);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
