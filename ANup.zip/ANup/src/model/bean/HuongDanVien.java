package model.bean;

/**				
 * HuongDanVien.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class HuongDanVien {
	private String maHDV;
	private String hoTen;
	private String ngaySinh;
	private int soNamKinhNghiem;
	private String maDiaPhuong;
	public HuongDanVien() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HuongDanVien(String maHDV, String hoTen, String ngaySinh, int soNamKinhNghiem, String maDiaPhuong) {
		super();
		this.maHDV = maHDV;
		this.hoTen = hoTen;
		this.ngaySinh = ngaySinh;
		this.soNamKinhNghiem = soNamKinhNghiem;
		this.maDiaPhuong = maDiaPhuong;
	}
	public String getMaHDV() {
		return maHDV;
	}
	public void setMaHDV(String maHDV) {
		this.maHDV = maHDV;
	}
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	public String getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public int getSoNamKinhNghiem() {
		return soNamKinhNghiem;
	}
	public void setSoNamKinhNghiem(int soNamKinhNghiem) {
		this.soNamKinhNghiem = soNamKinhNghiem;
	}
	public String getMaDiaPhuong() {
		return maDiaPhuong;
	}
	public void setMaDiaPhuong(String maDiaPhuong) {
		this.maDiaPhuong = maDiaPhuong;
	}
	
	
}
