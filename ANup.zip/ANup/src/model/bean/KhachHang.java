package model.bean;

/**				
 * KhachHang.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class KhachHang {
	private String maKH;
	private String tenKH;
	private int diemThuong;
	private int tongTien;
	
	public int getTongTien() {
		return tongTien;
	}
	public void setTongTien(int tongTien) {
		this.tongTien = tongTien;
	}

	public KhachHang() {
		super();
		// TODO Auto-generated constructor stub
	}
	public KhachHang(String maKH, String tenKH, int diemThuong) {
		super();
		this.maKH = maKH;
		this.tenKH = tenKH;
		this.diemThuong = diemThuong;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public int getDiemThuong() {
		return diemThuong;
	}
	public void setDiemThuong(int diemThuong) {
		this.diemThuong = diemThuong;
	}
	
	
}
