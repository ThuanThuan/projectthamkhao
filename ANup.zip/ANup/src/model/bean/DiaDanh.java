package model.bean;

/**				
 * DiaDanh.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class DiaDanh {
	private String maDiaDanh;
	private String tenDiaDanh;
	private int dienTich;
	private String gioiThieu;
	private String danhGia;
	private String maDiaPhuong;
	private int soLuongNguoi;
	
	public DiaDanh() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DiaDanh(String maDiaDanh, String tenDiaDanh, int dienTich, String gioiThieu, String danhGia,
			String maDiaPhuong, int soLuongNguoi) {
		super();
		this.maDiaDanh = maDiaDanh;
		this.tenDiaDanh = tenDiaDanh;
		this.dienTich = dienTich;
		this.gioiThieu = gioiThieu;
		this.danhGia = danhGia;
		this.maDiaPhuong = maDiaPhuong;
		this.soLuongNguoi= soLuongNguoi;
	}
	public String getMaDiaDanh() {
		return maDiaDanh;
	}
	public void setMaDiaDanh(String maDiaDanh) {
		this.maDiaDanh = maDiaDanh;
	}
	public String getTenDiaDanh() {
		return tenDiaDanh;
	}
	public void setTenDiaDanh(String tenDiaDanh) {
		this.tenDiaDanh = tenDiaDanh;
	}
	public int getDienTich() {
		return dienTich;
	}
	public void setDienTich(int dienTich) {
		this.dienTich = dienTich;
	}
	public String getGioiThieu() {
		return gioiThieu;
	}
	public void setGioiThieu(String gioiThieu) {
		this.gioiThieu = gioiThieu;
	}
	public String getDanhGia() {
		return danhGia;
	}
	public void setDanhGia(String danhGia) {
		this.danhGia = danhGia;
	}
	public String getMaDiaPhuong() {
		return maDiaPhuong;
	}
	public void setMaDiaPhuong(String maDiaPhuong) {
		this.maDiaPhuong = maDiaPhuong;
	}
	public int getSoLuongNguoi() {
		return soLuongNguoi;
	}
	public void setSoLuongNguoi(int soLuongNguoi) {
		this.soLuongNguoi = soLuongNguoi;
	}
	
	
}	
