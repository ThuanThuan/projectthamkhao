package model.bean;

/**				
 * DiaPhuong.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class DiaPhuong {
	private String maDiaPhuong;
	private String tenDiaPhuong;
	public DiaPhuong() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DiaPhuong(String maDiaPhuong, String tenDiaPhuong) {
		super();
		this.maDiaPhuong = maDiaPhuong;
		this.tenDiaPhuong = tenDiaPhuong;
	}
	public String getMaDiaPhuong() {
		return maDiaPhuong;
	}
	public void setMaDiaPhuong(String maDiaPhuong) {
		this.maDiaPhuong = maDiaPhuong;
	}
	public String getTenDiaPhuong() {
		return tenDiaPhuong;
	}
	public void setTenDiaPhuong(String tenDiaPhuong) {
		this.tenDiaPhuong = tenDiaPhuong;
	}
	
}
