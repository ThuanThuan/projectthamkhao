package model.bean;

/**				
 * ChuyenDi.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class ChuyenDi {
	private String maKH;
	private String maDiaDanh;
	private String maHDV;
	private int soLuong;
	private int mucPhi;
	public ChuyenDi() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ChuyenDi(String maKH, String maDiaDanh, String maHDV, int soLuong, int mucPhi) {
		super();
		this.maKH = maKH;
		this.maDiaDanh = maDiaDanh;
		this.maHDV = maHDV;
		this.soLuong = soLuong;
		this.mucPhi = mucPhi;
	}
	public int getMucPhi() {
		return mucPhi;
	}
	public void setMucPhi(int mucPhi) {
		this.mucPhi = mucPhi;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getMaDiaDanh() {
		return maDiaDanh;
	}
	public void setMaDiaDanh(String maDiaDanh) {
		this.maDiaDanh = maDiaDanh;
	}
	public String getMaHDV() {
		return maHDV;
	}
	public void setMaHDV(String maHDV) {
		this.maHDV = maHDV;
	}
	public int getSoLuong() {
		return soLuong;
	}
	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	
}
