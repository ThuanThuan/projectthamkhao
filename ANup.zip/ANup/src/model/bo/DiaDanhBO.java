package model.bo;

import java.util.ArrayList;

import model.bean.DiaDanh;
import model.bean.DiaPhuong;
import model.bean.HuongDanVien;
import model.bean.KhachHang;
import model.dao.DiaDanhDAO;

/**				
 * DiaDanhBO.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class DiaDanhBO {
	DiaDanhDAO diaDanhDAO = new DiaDanhDAO();
	
	public ArrayList<DiaDanh> getListDiaDanh() {
		// TODO Auto-generated method stub
		return diaDanhDAO.getListDiaDanh();
	}

	public ArrayList<KhachHang> getListKH() {
		// TODO Auto-generated method stub
		return diaDanhDAO.getListKH();
	}
	
	public ArrayList<HuongDanVien> getListHDV() {
		// TODO Auto-generated method stub
		return diaDanhDAO.getListHDV();
	}

	public void themChuyenDi(String maKH, String maDiaDanh, String maHDV, int soLuongNguoi, int mucPhi) {
		// TODO Auto-generated method stub
		diaDanhDAO.themChuyenDi(maKH, maDiaDanh, maHDV, soLuongNguoi, mucPhi);;
	}
	
	public void suaDiaDanh(String maDiaDanh, String tenDiaDanh, int dienTich, String gioiThieu,String danhGia, String maDiaPhuong, int soLuongNguoi) {
		diaDanhDAO.suaDiaDanh(maDiaDanh, tenDiaDanh, dienTich, gioiThieu,danhGia, maDiaPhuong, soLuongNguoi);;
	}

	public ArrayList<DiaPhuong> getListDiaPhuong() {
		// TODO Auto-generated method stub
		return diaDanhDAO.getListDiaPhuong();
	}

	public DiaDanh getThongTinDiaDanh(String maDiaDanh) {
		// TODO Auto-generated method stub
		return diaDanhDAO.getThongTinDiaDanh(maDiaDanh);
	}
	
	public KhachHang getTienHoanTra(String maKH){
		return diaDanhDAO.getTienHoanTra(maKH);
		
	}

	public ArrayList<DiaDanh> getListDiaDanhTimKiem(String searchText) {
		// TODO Auto-generated method stub
		return diaDanhDAO.getListDiaDanhTimKiem(searchText);
	}

	public void xoaDiaDanh(String maDiaDanh) {
		// TODO Auto-generated method stub
		diaDanhDAO.xoaDiaDanh(maDiaDanh);
	}

}
