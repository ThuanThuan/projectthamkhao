package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DiaDanh;
import model.bo.DiaDanhBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachDiaDanhForm;

/**
 * DanhSachDiaDanhAction.java
 *
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class DanhSachDiaDanhAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachDiaDanhForm danhSachDiaDanhForm = (DanhSachDiaDanhForm) form;
		
		//lay danh sach dia danh
		ArrayList<DiaDanh> listDiaDanh;
		DiaDanhBO diaDanhBO = new DiaDanhBO();
		listDiaDanh = diaDanhBO.getListDiaDanh();
		danhSachDiaDanhForm.setListDiaDanh(listDiaDanh);
		return mapping.findForward("dsDiaDanh");
		
	}
}

