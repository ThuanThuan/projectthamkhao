package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachDiaDanhForm;
import model.bo.DiaDanhBO;

/**				
 * XoaDiaDanhAction.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class XoaDiaDanhAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		DanhSachDiaDanhForm danhSachDiaDanhForm = (DanhSachDiaDanhForm) form;

		DiaDanhBO diaDanhBO = new DiaDanhBO();	
		//xoa sinh vien
		String maDiaDanh=danhSachDiaDanhForm.getMaDiaDanh();
		//nhan nut Xac nhan o trang Xoa sinh vien
			diaDanhBO.xoaDiaDanh(maDiaDanh);
			return mapping.findForward("xoaSVxong");
	}
}
