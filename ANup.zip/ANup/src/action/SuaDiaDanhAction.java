package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachDiaDanhForm;
import model.bean.DiaDanh;
import model.bean.DiaPhuong;
import model.bo.DiaDanhBO;


/**				
 * SuaDiaDanhAction.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class SuaDiaDanhAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		DanhSachDiaDanhForm danhSachDiaDanhForm = (DanhSachDiaDanhForm) form;

		//lay danh sach dia phuong
		DiaDanhBO diaDanhBO = new DiaDanhBO();
		ArrayList<DiaPhuong> listDiaPhuong = diaDanhBO.getListDiaPhuong();
		danhSachDiaDanhForm.setListDiaPhuong(listDiaPhuong);
		
		//sua dia danh
		String maDiaDanh=danhSachDiaDanhForm.getMaDiaDanh();
		if("submit".equals(danhSachDiaDanhForm.getSubmit())){					//nhan nut Xac nhan o trang Them sinh vien
			String tenDiaDanh= danhSachDiaDanhForm.getTenDiaDanh();
			int dienTich = danhSachDiaDanhForm.getDienTich();
			String gioiThieu = danhSachDiaDanhForm.getGioiThieu();
			String danhGia = danhSachDiaDanhForm.getDanhGia();
			String maDiaPhuong = danhSachDiaDanhForm.getMaDiaPhuong();
			int soLuongNguoi = danhSachDiaDanhForm.getSoLuongNguoi();
			diaDanhBO.suaDiaDanh(maDiaDanh, tenDiaDanh, dienTich, gioiThieu,danhGia, maDiaPhuong, soLuongNguoi);;
			return mapping.findForward("suaSVxong");
		} else {
			//chuyen sang trang Sua sinh vien
			DiaDanh diaDanh = diaDanhBO.getThongTinDiaDanh(maDiaDanh);
			danhSachDiaDanhForm.setTenDiaDanh(diaDanh.getTenDiaDanh());
			danhSachDiaDanhForm.setDienTich(diaDanh.getDienTich());
			danhSachDiaDanhForm.setGioiThieu(diaDanh.getGioiThieu());
			danhSachDiaDanhForm.setDanhGia(diaDanh.getDanhGia());
			danhSachDiaDanhForm.setMaDiaPhuong(diaDanh.getMaDiaPhuong());
			danhSachDiaDanhForm.setSoLuongNguoi(diaDanh.getSoLuongNguoi());
			return mapping.findForward("suaSV");
		}
	}
}
