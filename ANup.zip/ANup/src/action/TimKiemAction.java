package action;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachDiaDanhForm;
import model.bean.DiaDanh;
import model.bo.DiaDanhBO;


public class TimKiemAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachDiaDanhForm danhSachDiaDanhForm = (DanhSachDiaDanhForm) form;
		
		//lay danh sach sinh vien
		ArrayList<DiaDanh> listDiaDanhTimKiem;
		DiaDanhBO diaDanhBO = new DiaDanhBO();
		String searchText = danhSachDiaDanhForm.getSearchText();
		if(searchText==null || searchText.length()==0){
			listDiaDanhTimKiem = diaDanhBO.getListDiaDanh();
		} else {
			searchText = searchText.trim();
			byte[] bt = searchText.getBytes(StandardCharsets.ISO_8859_1);
			searchText = new String(bt,StandardCharsets.UTF_8);
			listDiaDanhTimKiem=diaDanhBO.getListDiaDanhTimKiem(searchText);
		}
		danhSachDiaDanhForm.setListDiaDanh(listDiaDanhTimKiem);
		danhSachDiaDanhForm.setSearchText(searchText);
		
		return mapping.findForward("timKiemThanhCong");
}
}
