package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.KhachHangForm;
import model.bean.KhachHang;
import model.bo.DiaDanhBO;

/**				
 * TienHoanTraAction.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class TienHoanTraAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		KhachHangForm khachHangForm = (KhachHangForm) form;
		DiaDanhBO diaDanhBO = new DiaDanhBO();
		StringProcess sp = new StringProcess();
		
		if("submit".equals(khachHangForm.getSubmit())){
			//
			String maKH = khachHangForm.getMaKH();
			KhachHang khachHang = diaDanhBO.getTienHoanTra(maKH);
			khachHangForm.setTienHoanTra(sp.tienHoanTra(khachHang.getTongTien(), khachHang.getDiemThuong()));
			khachHangForm.setMaKH(maKH);;
			return mapping.findForward("tinhTienThanhCong");
		} else {
			return mapping.findForward("tinhTien");
		}
	}
}
