package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.ChuyenDiForm;
import model.bean.DiaDanh;
import model.bean.HuongDanVien;
import model.bean.KhachHang;
import model.bo.DiaDanhBO;

/**				
 * ThemChuyenDiAction.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class ThemChuyenDiAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		ChuyenDiForm chuyenDiForm = (ChuyenDiForm) form;
		
		//lay danh sach KH
		DiaDanhBO diaDanhBO = new DiaDanhBO();
		ArrayList<KhachHang> listKhachHang = diaDanhBO.getListKH();
		chuyenDiForm.setListKhachHang(listKhachHang);
		
		//lay danh sach DiaDanh
		ArrayList<DiaDanh> listDiaDanh = diaDanhBO.getListDiaDanh();
		chuyenDiForm.setListDiaDanh(listDiaDanh);
		
		//lay danh sach HDV
		ArrayList<HuongDanVien> listHDV = diaDanhBO.getListHDV();
		chuyenDiForm.setListHDV(listHDV);
		
		if("submit".equals(chuyenDiForm.getSubmit())){		//nhan nut Xac nhan o trang Them sinh vien
			String maKH = chuyenDiForm.getMaKH();
			String maDiaDanh = chuyenDiForm.getMaDiaDanh();
			String maHDV = chuyenDiForm.getMaHDV();
			int soLuongNguoi = chuyenDiForm.getSoLuongNguoi();
			int mucPhi = chuyenDiForm.getMucPhi();
			diaDanhBO.themChuyenDi(maKH, maDiaDanh, maHDV, soLuongNguoi, mucPhi);
			return mapping.findForward("themSVxong");
		} else {											//chuyen sang trang Them sinh vien
			return mapping.findForward("themSV");
		}
	}
}
