package form;

import org.apache.struts.action.ActionForm;

/**				
 * KhachHangForm.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class KhachHangForm extends ActionForm {
	private String maKH;
	private String tenKH;
	private int diemThuong;
	private int tongTien;
	private int tienHoanTra;
	private String submit;
	
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public int getDiemThuong() {
		return diemThuong;
	}
	public void setDiemThuong(int diemThuong) {
		this.diemThuong = diemThuong;
	}
	public int getTongTien() {
		return tongTien;
	}
	public void setTongTien(int tongTien) {
		this.tongTien = tongTien;
	}
	public int getTienHoanTra() {
		return tienHoanTra;
	}
	public void setTienHoanTra(int tienHoanTra) {
		this.tienHoanTra = tienHoanTra;
	}
	
	
}
