package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DiaDanh;
import model.bean.DiaPhuong;


/**				
 * DanhSachDiaDanhForm.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class DanhSachDiaDanhForm extends ActionForm{
	private ArrayList<DiaDanh> listDiaDanh;
	private ArrayList<DiaPhuong> listDiaPhuong;
	private String maDiaDanh;
	private String tenDiaDanh;
	private int dienTich;
	private String gioiThieu;
	private String danhGia;
	private String maDiaPhuong;
	private int soLuongNguoi;
	private String submit;
	private String searchText;
	
	
	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	public ArrayList<DiaDanh> getListDiaDanh() {
		return listDiaDanh;
	}

	public ArrayList<DiaPhuong> getListDiaPhuong() {
		return listDiaPhuong;
	}

	public void setListDiaPhuong(ArrayList<DiaPhuong> listDiaPhuong) {
		this.listDiaPhuong = listDiaPhuong;
	}

	public void setListDiaDanh(ArrayList<DiaDanh> listDiaDanh) {
		this.listDiaDanh = listDiaDanh;
	}

	public String getMaDiaDanh() {
		return maDiaDanh;
	}

	public void setMaDiaDanh(String maDiaDanh) {
		this.maDiaDanh = maDiaDanh;
	}

	public String getTenDiaDanh() {
		return tenDiaDanh;
	}

	public void setTenDiaDanh(String tenDiaDanh) {
		this.tenDiaDanh = tenDiaDanh;
	}

	public int getDienTich() {
		return dienTich;
	}

	public void setDienTich(int dienTich) {
		this.dienTich = dienTich;
	}

	public String getGioiThieu() {
		return gioiThieu;
	}

	public void setGioiThieu(String gioiThieu) {
		this.gioiThieu = gioiThieu;
	}

	public String getDanhGia() {
		return danhGia;
	}

	public void setDanhGia(String danhGia) {
		this.danhGia = danhGia;
	}

	public String getMaDiaPhuong() {
		return maDiaPhuong;
	}

	public void setMaDiaPhuong(String maDiaPhuong) {
		this.maDiaPhuong = maDiaPhuong;
	}

	public int getSoLuongNguoi() {
		return soLuongNguoi;
	}

	public void setSoLuongNguoi(int soLuongNguoi) {
		this.soLuongNguoi = soLuongNguoi;
	}

	
	
}
