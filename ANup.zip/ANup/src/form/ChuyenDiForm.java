package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DiaDanh;
import model.bean.HuongDanVien;
import model.bean.KhachHang;

/**				
 * ChuyenDiForm.java		
 *				
 * Version 1.0				
 *				
 * Date: July 18, 2017		
 *				
 * Copyright 				
 *				
 * Modification Logs:				
 * DATE                 AUTHOR          DESCRIPTION				
 * -----------------------------------------------------------------------				
 * July 18, 2017       ThuanHV1            Create				
 */

public class ChuyenDiForm extends ActionForm {
	private String submit;
	private int soLuongNguoi;
	private String maKH;
	private String tenKH;
	private String maDiaDanh;
	private String tenDiaDanh;
	private String maHDV;
	private String hoTen;
	private int mucPhi;
	private ArrayList<KhachHang> listKhachHang;
	private ArrayList<DiaDanh> listDiaDanh;
	private ArrayList<HuongDanVien> listHDV;
	
	
	public int getMucPhi() {
		return mucPhi;
	}
	public void setMucPhi(int mucPhi) {
		this.mucPhi = mucPhi;
	}
	
	
	public String getMaKH() {
		return maKH;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public String getTenDiaDanh() {
		return tenDiaDanh;
	}
	public void setTenDiaDanh(String tenDiaDanh) {
		this.tenDiaDanh = tenDiaDanh;
	}
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getMaDiaDanh() {
		return maDiaDanh;
	}
	public void setMaDiaDanh(String maDiaDanh) {
		this.maDiaDanh = maDiaDanh;
	}
	public String getMaHDV() {
		return maHDV;
	}
	public void setMaHDV(String maHDV) {
		this.maHDV = maHDV;
	}
	
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public int getSoLuongNguoi() {
		return soLuongNguoi;
	}
	public void setSoLuongNguoi(int soLuongNguoi) {
		this.soLuongNguoi = soLuongNguoi;
	}
	public ArrayList<KhachHang> getListKhachHang() {
		return listKhachHang;
	}
	public void setListKhachHang(ArrayList<KhachHang> listKhachHang) {
		this.listKhachHang = listKhachHang;
	}
	public ArrayList<DiaDanh> getListDiaDanh() {
		return listDiaDanh;
	}
	public void setListDiaDanh(ArrayList<DiaDanh> listDiaDanh) {
		this.listDiaDanh = listDiaDanh;
	}
	public ArrayList<HuongDanVien> getListHDV() {
		return listHDV;
	}
	public void setListHDV(ArrayList<HuongDanVien> listHDV) {
		this.listHDV = listHDV;
	}
	
	
}
